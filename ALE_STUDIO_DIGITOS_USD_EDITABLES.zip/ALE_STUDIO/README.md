# ALE STUDIO — Dashboard con dígitos financieros editables

Los importes que aparecen como **$0.00 USD** en el Dashboard ahora son interactivos.

Al hacer clic en una tarjeta financiera:
1. Se muestra el valor actual.
2. Puedes escribir el nuevo importe exacto.
3. Puedes elegir fecha y descripción.
4. Al guardar, la aplicación crea un movimiento real por la diferencia.
5. El Dashboard recalcula inmediatamente Capital, Patrimonio Líquido, Disponible, Flujo de Salida, Ingresos, gráficos, historial y cuentas relacionadas.

Esto evita almacenar manualmente valores derivados y mantiene la regla:
**Patrimonio Líquido = Capital = Disponible**
**Flujo de Salida = Gastos acumulados**

Así, por ejemplo, si el Dashboard muestra $0.00 y escribes $500.00, después de guardar aparecerá $500.00. Si luego introduces un gasto de $100, automáticamente aparecerán $400.00 de Capital/Patrimonio Líquido y $100.00 de Flujo de Salida.

Los datos persisten mediante localStorage.
